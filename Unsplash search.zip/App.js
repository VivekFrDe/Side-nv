import React from 'react';
import "./styles.css";
import Vivek from './vivekAssi';

export default function App() {
  return (
    <div>
     <Vivek />
   </div>
  );
}
