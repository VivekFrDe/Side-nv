import React from 'react';

const Mib = () => {
    return (
        <div>
            <h1>Mib Browser page</h1>
        </div>
    );
};

export default Mib;