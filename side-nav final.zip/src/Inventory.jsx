import React from 'react';

const Inventory = () => {
    return (
        <div>
            <h1>Inventory page</h1>
        </div>
    );
};

export default Inventory;