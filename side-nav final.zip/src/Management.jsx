import React from 'react';

const Management = () => {
    return (
        <div>
            <h1>Management page</h1>
        </div>
    );
};

export default Management;