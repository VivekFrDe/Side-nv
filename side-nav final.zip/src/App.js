import React from 'react';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Sidebar from './Sidebar';
import Dashboard from './Dashboard.jsx';
import Mib from './Mib.jsx';
import Management from './Management.jsx';
import Inventory from './Inventory.jsx';
import Account from './Account.jsx';

const App = () => {
  return (
    <BrowserRouter>
      <Sidebar>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/Mib" element={<Mib />} />
          <Route path="/Inventory" element={<Inventory />} />
          <Route path="/Management" element={<Management />} />
          <Route path="/Account" element={<Account />} />
        </Routes>
      </Sidebar>
    </BrowserRouter>
  );
};

export default App;