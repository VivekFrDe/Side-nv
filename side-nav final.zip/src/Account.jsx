import React from 'react';

const Account = () => {
    return (
        <div>
            <h1>Account page</h1>
        </div>
    );
};

export default Account;